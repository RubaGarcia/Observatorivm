package observatorio.app;

import observatorio.presentation.MainMenu;

public class runAppObservatorio {

	public static void main(String[] args) {
		
		new MainMenu().run();

	}

}
